<?php
namespace app\blog\controller;

class Link
{

}