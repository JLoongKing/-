<?php
namespace app\blog\controller;

class Blogtype
{

}