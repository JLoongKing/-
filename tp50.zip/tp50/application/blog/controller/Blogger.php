<?php
namespace app\blog\controller;

class Blogger
{

}