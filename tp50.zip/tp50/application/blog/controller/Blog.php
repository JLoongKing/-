<?php
namespace app\blog\controller;

class Blog extends Base
{
  

}