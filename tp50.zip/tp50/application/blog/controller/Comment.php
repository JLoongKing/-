<?php
namespace app\blog\controller;

class Comment
{

}