<?php
namespace app\blog\model;

use think\Model;

class Link extends Model
{

}