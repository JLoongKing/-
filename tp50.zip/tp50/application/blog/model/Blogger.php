<?php
namespace app\blog\model;

use think\Model;

class Blogger extends Model
{

}