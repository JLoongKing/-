<?php
return [
    'appid' => "101482348",
    'appkey' => "6642b4db4f6907509e544ce8aaf55a2d",
    'callback' => "http://www.jloongking.cn/tp50/public/qq/index/index?type=1",
    'scope' => "get_user_info",
    'errorReport' => true,
    'storageType' => "file",
    'host' => 'localhost',
    'user' => 'root',
    'password' => 'root',
    'database' => 'test',
];