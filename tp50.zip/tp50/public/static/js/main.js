$(document).ready(function() {
date();
    // $("#frist-words").show({
    //     duration: 1000,
    //     complete: function() {
    //          $("#second-words").show({
    //             duration: 1000,
    //              complete: function() {
    //                  $("#third-words").show({
    //                      duration: 1000
    //                  })
    //              }
    //         })
    //     }
    // })


});
function date(){
var time=new Date();
var tr=document.getElementById("tr")
    var vYear = time.getFullYear();
    var vMon = time.getMonth() + 1;
    var vDay = time.getDate();
    var s=vYear+"年"+vMon+"月"+vDay+"日";
    var dTitle=window.document.getElementById("dTitle");
    dTitle.innerHTML = s;
    time.setDate(1);

    var monthDays = new Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
    var hanzi = new Array("日","一","二","三","四","五","六");
    if (((vYear % 4 == 0) && (vYear % 100 != 0)) || (vYear % 400 == 0)) monthDays[1] = 29;
    var nDays = monthDays[vMon-1];
    for (var i=0; i<7;i++) {

        var s1 = "<div class='td'style='width: 14%'>"+hanzi[i]+"</div>";
        tr.innerHTML += s1


    }
    for (var i=0; i<time.getDay();i++) {


        var s1 = "<div class='td'style='width: 14%'>"+" "+"</div>";
        tr.innerHTML += s1


    }
    for (i=1; i<=nDays; i++) {


        if(i==vDay){
            var s1 = "<div class='td'style='width: 14%; background:url(/tp50/public/static/img/yes1.png) center;background-size:70%;background-repeat: no-repeat;'>"+i+"</div>";
        }
        else{
            var s1 = "<div class='td'style='width: 14%'>"+i+"</div>";
        }
        tr.innerHTML += s1
    }

}