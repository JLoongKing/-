<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"/opt/lampp/htdocs/tp50/public/../application/qq/view/index/qqloginview.html";i:1528447965;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>登陆成功</title>
    <!-- <script type="text/javascript" src="http://qzonestyle.gtimg.cn/qzone/openapi/qc_loader.js" charset="utf-8" data-callback="true"></script> -->
    <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
    <script src="https://cdn.bootcss.com/jquery-cookie/1.4.1/jquery.cookie.js"></script>
    <script type="text/javascript">
    </script>
</head>

<body>
    <div onclick="" style="width:80%;margin:40px auto;text-align:center"><img style="width:50%;border-radius:50%;" id="icon" src="/tp50/public/static/images/qq.jpg" alt="点击登陆" data-bd-imgshare-binded="1">
        <p style="margin:20px;font-size:18px;color:dimgray">欢迎您！<span id='nickname'></span></p>
    </div>
</body>
<script>
    function GetQueryString(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return decodeURI(r[2]);
        return null;
    }
    if (GetQueryString('nickname') == null || GetQueryString('openid') == null || GetQueryString('icon') == null) {
        alert("出现错误!");
    }
    // $.cookie('nickname', GetQueryString('nickname'));
    // $.cookie('openid', GetQueryString('openid'));
    // $.cookie('icon', GetQueryString('icon'));
    $("#nickname").html(GetQueryString('nickname'));
    $("#icon").attr('src', GetQueryString('icon'));
</script>

</html>