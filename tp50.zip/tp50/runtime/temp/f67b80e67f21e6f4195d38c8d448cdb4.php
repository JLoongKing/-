<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:69:"C:\xampp\htdocs\tp50\public/../application/blog\view\index\index.html";i:1526177587;s:78:"C:\xampp\htdocs\tp50\public/../application/blog\view\index\include\header.html";i:1526180571;s:77:"C:\xampp\htdocs\tp50\public/../application/blog\view\index\include\right.html";i:1526177587;s:78:"C:\xampp\htdocs\tp50\public/../application/blog\view\index\include\footer.html";i:1526177587;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">

<head>
    <meta charset="UTF-8">
    <title>博客首页</title>
    <link rel="stylesheet" href="/tp50/public/static/css/main.css">

    <link href="/tp50/public/static/css/banner.css" rel="stylesheet">

    <!-- 最新版本的 Bootstrap 核心 CSS 文件 -->
    <link rel="stylesheet" href="/tp50/public/static/bootstrap/bootstrap.css" />

    <script src="/tp50/public/static/bootstrap/jquery.js"></script>
    <script src="/tp50/public/static/bootstrap//bootstrap.min.js"></script>
    <script type="text/javascript" src="/tp50/public/static/js/banner.js"></script>
    <script type="text/javascript" src="/tp50/public/static/ueditor/ueditor.parse.js"></script>
    <script type="text/javascript" src="/tp50/public/static/ueditor/ueditor.config.js"></script>
    <script type="text/javascript" src="/tp50/public/static/ueditor/ueditor.all.min.js"></script>
    <script type="text/javascript" src="/tp50/public/static/ueditor/lang/zh-cn/zh-cn.js"></script>
    <style>
        body {
            min-width: 1080px;
            max-width: 1366px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="header">
        <div id="banner" style="width:100%;height:350px;">
            <div id="banner_bg">
            </div>
            <!--标题背景-->
            <div id="banner_info" style="display:none">
            </div>
            <!--标题-->
            <ul style="display:none">
                <li class="on">
                    1
                </li>
                <li>
                    2
                </li>
                <li>
                    3
                </li>
                <li>
                    4
                </li>
            </ul>
            <div id="banner_list">
                <a href="#" target="_blank">
                    <img id="img1" src="" title="banner图1" alt="banner图1">
                </a>
                <a href="#" target="_blank">
                    <img id="img2" src="" title="banner图2" alt="banner图2">
                </a>
                <a href="#" target="_blank">
                    <img id="img3" src="" title="banner图3" alt="banner图3">
                </a>
                <a href="#" target="_blank">
                    <img id="img4" src="" title="banner图4" alt="banner图4">
                </a>
            </div>

        </div>
        <div class="bg">

            <div class="nav">
                <ul>
                    <li class="nav_item">
                        <a href="/tp50/public/blog/index/review?viewname=index/index" class="home">HOME</a>
                    </li>
                    <!-- 
                    <li class="nav_item">
                        <a href="#">最近专题</a>
                    </li> -->
                    <!-- <li class="nav_item"><a href="#">留下足迹</a></li> -->
                    <li class="nav_item">
                        <a href="/tp50/public/blog/index/review?viewname=index/aboutme">关于我</a>
                    </li>

                    <div class="clear"></div>
                </ul>
            </div>
            <div class="mood" id="sign">

            </div>
            <div class="clear"></div>
        </div>
    </div>
    <div class="middle-body">
        <script>
            $username = "JLoongKing"
                //获取原签名信息
                //post 请求
            $.post("/tp50/public/blog/index/select", {
                "tablename": "t_blogger", //表名
                "sql": '{"userName":"=,' + $username + '"}'
            }, function(result) {
                //显示信息
                $("#sign").html(result[0].sign)

            });
            getdata();
            //获取数据
            function getdata() {
                //post 请求
                $.post("/tp50/public/blog/index/select", {
                    "tablename": "t_banner", //表名
                    "sql": '', //查询的条件
                    "limit": "0,4" //分页
                }, function(result) {
                    //回掉函数处理，输出结果
                    //如果没有获取错误码
                    if (result.code != 401) {

                        $i = 1;
                        //遍历结果处理数据进行输出
                        result.forEach(function(item) {
                            $("#img" + $i).attr("src", item.imgurl);
                            $i++;
                        });

                    } else {
                        alert(result.info);
                    }
                });
            }
        </script>
<div class="left">
    <div id="alltypes" style="width:100%;margin:40px auto; text-align:center;"></div>
    <div id="thistitle" style="width:100%;margin:10px auto; text-align:center;font-size:20px">全部博客</div>
    <div style="width:100%;margin:30px auto; text-align:center;">共有
        <span id="count">0</span>个相关项</div>

    <!--note-->
    <div class="note">
        <div id="notelist">

        </div>
        <ul class="pager">
            <li id="older" onclick="older()" class="previous">
                <a>&larr;Older</a>
            </li>
            <li>
                <a id="page">1</a>
            </li>
            <li id="more" class="next" onclick="next()">
                <a>Next &rarr;</a>
            </li>
        </ul>
    </div>
    <!--note结束-->

</div>
<!--left结束-->

<script>
    $typelist = "";
    //post 请求
    $.post("/tp50/public/blog/index/select", {
        "tablename": "t_blogtype", //表名
        "sql": '', //查询的条件
        "limit": "0,50" //分页
    }, function(result) {
        //回掉函数处理，输出结果
        //如果没有获取错误码
        if (result.code != 401) {
            $typelist = result;
            $html = "";
            if (GetQueryString("blogid") == null || GetQueryString("blogid") == '') {

            } else {

                $("#thistitle").html(gettype(GetQueryString("blogid")));
            }

            //遍历结果处理数据进行输出
            result.forEach(function(item) {

                $colors = ['label label-default', 'label label-primary', 'label label-success', 'label label-info', 'label label-warning', 'label label-danger'];
                $colorid = Math.ceil(Math.random() * 6);
                $inner = "<a href='/tp50/public/blog/index/review?viewname=index&blogid=" + item.id + "'><span style='margin:10px;' class='" + $colors[$colorid - 1] + "'>" + item.typeName + "</span></a>";
                $html += $inner;
            });
            $("#alltypes").html($html);
        } else {
            alert(result.info);
        }
    });

    function gettype($tid) {
        for (j = 0; j < $typelist.length; j++) {
            if ($typelist[j].id == $tid) {
                return $typelist[j].typeName;
            }
        }
    }

    function GetQueryString(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]);
        return null;
    }
    $blogtype = "";
    if (GetQueryString("blogid") == null || GetQueryString("blogid") == '') {
        $blogtype = "";
    } else {
        $blogtype = '{"typeId":"=,' + GetQueryString("blogid") + '"}';
    }


    $eachnum = 5;
    $maxnum = 0;
    //获取分页最大数量
    //post 请求
    $.post("/tp50/public/blog/index/selectnum", {
        "tablename": "t_blog", //表名
        "sql": $blogtype
    }, function(result) {
        // 显示总条数
        $("#count").text(result);
        //获取数据数量除每页条数
        $maxnum = parseInt(result / $eachnum) + 1;
        if ($maxnum == 0) {
            $("#notelist").append("<div style='margin-top：40px; text-align:center'>到到底了(-_-)!</div>");
        }
    });
    //初始页面数
    $page = 1;
    //页面初始化
    pagealert();

    //获取分页数据
    function getdata() {

        $("#notelist").html("");
        //post 请求
        $.post("/tp50/public/blog/index/select", {
            "tablename": "t_blog", //表名
            "sql": $blogtype, //查询的条件
            "limit": ($page - 1) * $eachnum + "," + $page * $eachnum //分页
        }, function(result) {
            //回掉函数处理，输出结果
            //如果没有获取错误码
            if (result.code != 401) {
                $i = 1;
                $html = "";
                //遍历结果处理数据进行输出
                result.forEach(function(item) {
                    $lihtml = '<!--note img--><div class="not"><p class="note_title">小说井龙王开始热更啦！</p><p class="note_infor"> &nbsp; &nbsp; 作者：jloong &nbsp; &nbsp;类型：<span class="type">创作</span></p><!--note介绍--><div class="note_body"><p>西游世界各教纷争，井龙王是否为龙，他为何屈居深井，世界为棋盘，洪荒大地再起浩劫。潜龙勿用，一飞冲天。 这是一个由封神结束开始的故事。面对大劫，他将如何在有限时间内成为大能翻云覆雨！</p></div><div class="clear"></div><!--更新时间作者--><div class="infor"><p><img src="/tp50/public/static//img/time.jpg" alt="">更新时间：<span class="updatetime">1995.12.14</span> &nbsp; &nbsp; 浏览次数：<span class="clickHit">12</span>  &nbsp; &nbsp;点赞次数：<span class="replyHit">12</span>  &nbsp; &nbsp;</p></div></div>'
                    $("#notelist").append("<a style='text-decoration : none;color:#666666' href='/tp50/public/blog/index/review?viewname=index/blog&blogid=" + item.id + "'><div id='li" + $i + "'></div></a>");
                    $("#li" + $i).html($lihtml);
                    $("#li" + $i).children(".not").children(".note_infor").children(".type").html(gettype(item.typeId));
                    $("#li" + $i).children(".not").children(".note_title").html(item.title);
                    // $("#li" + $i).children(".not").children(".note_img").children("img").attr("src", "/tp50/public/static/img/novbg.jpg");
                    $("#li" + $i).children(".not").children(".note_body").html(item.summary);
                    $("#li" + $i).children(".not").children(".infor").children("p").children(".updatetime").html(item.updatetime);
                    $("#li" + $i).children(".not").children(".infor").children("p").children(".clickHit").html(item.clickHit);
                    $("#li" + $i).children(".not").children(".infor").children("p").children(".replyHit").html(item.replyHit);
                    $i++;
                });
                if (result.lenth < 5) {
                    $("#notelist").append("<div style='margin-top：40px; text-align:center'>到到底了(-_-)!</div>");
                }
                $("#tbody").html($html);
            } else {
                alert(result.info);
            }
        });
    }
    //下一页
    function next() {
        $page++;
        pagealert();
    }
    //上一页
    function older() {
        $page--;
        pagealert();
    }
    // 页面变化处理
    function pagealert() {
        if ($page <= 1) {
            if ($page == 1) {
                getdata();
            }
            $page = 1;
            $("#older").addClass("disabled");
            $("#more").removeClass("disabled");
            $("#page").text($page);
        } else if ($page >= $maxnum) {
            if ($page == $maxnum) {
                getdata();
            }
            $page = $maxnum;
            $("#more").addClass("disabled");
            $("#older").removeClass("disabled");
            $("#page").text($page);
        } else {
            $("#older").removeClass("disabled");
            $("#more").removeClass("disabled");
            $("#page").text($page);
        }

    }
</script> 
<div class="right"><!--右侧布局-->
    <div class="date">
        <div id="lastMon"><</div>
<div id="dTitle"></div>
        <div id="nextMon">></div>
        <div id="dataIn">
            <div id="tr" class="tr">

            </div>

        </div>



    </div>

    <!--data结束-->
<div class="new">
    <p>最新<a id="gren">文章</a></p>
    <ol id="newlist">
    <li class=""><a id="newbloglist1" style=" color: orangered ;" href="#">1sadsafsad</a></li>
    <li class=""><a id="newbloglist2" href="#">2asdsadasfas</a></li>
    <li class=""><a id="newbloglist3" href="#" >3asdfasfadgsd</a></li>
    <li class=""><a id="newbloglist4" href="#">4asfdsgfdh</a></li>
    </ol>
</div><!--new 结束-->
   <div class="hot"> <!--hot开始-->
  <p>热度排行</p>
       <ul id="hotlist">
           <li type="square" class=""><a id="hotbloglist1" style=" color: orangered ;" href="#">1sadsafsad</a></li>
           <li type="square" class=""><a id="hotbloglist2" href="#">2asdsadasfas</a></li>
           <li type="square" class=""><a id="hotbloglist3" href="#" >3asdfasfadgsd</a></li>
           <li type="square"  class=""><a id="hotbloglist4" href="#">4asfdsgfdh</a></li>
       </ul>
  </div> <!--hot结束-->
</div><!--右侧结束-->
<div class="clear"></div>
</div>
<!-- <p id="frist-words">喜欢吗？</p>
<p id="second-words">喜欢就选我吧！</p>
<p id="third-words">与你携手共进！</p> -->
</body>
<script>
      getdata1("id desc","#newbloglist");
      getdata1("clickHit desc","#hotbloglist");
    //获取数据
    function getdata1($order,$itemname) {
        //post 请求
        $.post("/tp50/public/blog/index/selectorder", {
            "tablename": "t_blog", //表名
            "sql": '', //查询的条件
            "order": $order, //排序规则
            "limit": "0,4" //分页
        }, function (result) {
            //回掉函数处理，输出结果
            //如果没有获取错误码
            if (result.code != 401) {
                $i = 1;
                //遍历结果处理数据进行输出
                result.forEach(function (item) {
                    $($itemname+$i).html(item.title);
                    $($itemname+$i).attr("href","/tp50/public/blog/index/review?viewname=index/blog&blogid="+item.id);
                    $i++;
                });
              
            } else {
                alert(result.info);
            }
        });
    }
</script>
<script src="/tp50/public/static/js/main.js"></script>
</html> <div style="clear:both" />
<!--采用container-fluid，使得整个页尾的宽度为100%，并设置它的背景色-->
<footer class="container-fluid foot-wrap">
    <!--采用container，使得页尾内容居中 -->
    <div class="container">
        <div class="row">
            <div class="row-content col-lg-4 col-sm-4 col-xs-6">
                <h3>分享到</h3>
                <ul>
                    <div class="bdsharebuttonbox">
                        <a href="#" class="bds_more" data-cmd="more"></a>
                        <a href="#" class="bds_qzone" data-cmd="qzone"></a>
                        <a href="#" class="bds_tsina" data-cmd="tsina"></a>
                        <a href="#" class="bds_tqq" data-cmd="tqq"></a>
                        <a href="#" class="bds_renren" data-cmd="renren"></a>
                        <a href="#" class="bds_weixin" data-cmd="weixin"></a>
                    </div>
                    <script>
                        window._bd_share_config = {
                            "common": {
                                "bdSnsKey": {},
                                "bdText": "",
                                "bdMini": "2",
                                "bdPic": "",
                                "bdStyle": "0",
                                "bdSize": "16"
                            },
                            "share": {},
                            "image": {
                                "viewList": ["qzone", "tsina", "tqq", "renren", "weixin"],
                                "viewText": "分享到：",
                                "viewSize": "16"
                            },
                            "selectShare": {
                                "bdContainerClass": null,
                                "bdSelectMiniList": ["qzone", "tsina", "tqq", "renren", "weixin"]
                            }
                        };
                        with(document) 0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = 'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=' + ~(-new Date() / 36e5)];
                    </script>
                </ul>
            </div>
            <div class="row-content col-lg-4 col-sm-4 col-xs-6">
                <h3>设计者</h3>
                <ul>
                    <li><a href="https://www.jloongking.cn">JLoongKing</a></li>
                </ul>
            </div>
            <div class="row-content col-lg-4 col-sm-4 col-xs-6">
                <h3>友情链接</h3>
                <ul id="linklist">
                    <li><a href="https://www.jloongking.cn">JLoongKing</a></li>
                </ul>
            </div>


        </div>
        <!--/.row -->
    </div>
    <!--/.container-->
    <p align="center" style="margin-top: 20px; font-size:10px;color: #878B91;">
        备案号辽ICP备16015900号
    </p>
    <p align="center" style="margin-top: 20px;color:#878B91;">
        Copyright &copy;2018 JLoongKing
    </p>


</footer>
<script>
    //post 请求
    $.post("/tp50/public/blog/index/select", {
        "tablename": "t_link", //表名
        "sql": '', //查询的条件
        "limit": '0,10' //分页
    }, function(result) {
        $html = "";
        //将每一项数据进行遍历，生成html代码
        //回掉函数处理，输出结果
        //如果没有获取错误码
        if (result.code != 401) {
            //遍历结果处理数据进行输出
            result.forEach(function(item) {
                $html += " <li><a href='" + item.linkUrl + "'>" + item.linkName + "</a></li>"
            });

        } else {
            alert(result.info);
        }
        $("#linklist").html($html);

    });
</script>