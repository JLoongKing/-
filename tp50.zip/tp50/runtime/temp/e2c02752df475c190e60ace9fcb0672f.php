<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:71:"C:\xampp\htdocs\tp50\public/../application/blog\view\index\aboutme.html";i:1526177586;s:78:"C:\xampp\htdocs\tp50\public/../application/blog\view\index\include\header.html";i:1526180571;s:77:"C:\xampp\htdocs\tp50\public/../application/blog\view\index\include\right.html";i:1526177587;s:78:"C:\xampp\htdocs\tp50\public/../application/blog\view\index\include\footer.html";i:1526177587;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">

<head>
    <meta charset="UTF-8">
    <title>博客首页</title>
    <link rel="stylesheet" href="/tp50/public/static/css/main.css">

    <link href="/tp50/public/static/css/banner.css" rel="stylesheet">

    <!-- 最新版本的 Bootstrap 核心 CSS 文件 -->
    <link rel="stylesheet" href="/tp50/public/static/bootstrap/bootstrap.css" />

    <script src="/tp50/public/static/bootstrap/jquery.js"></script>
    <script src="/tp50/public/static/bootstrap//bootstrap.min.js"></script>
    <script type="text/javascript" src="/tp50/public/static/js/banner.js"></script>
    <script type="text/javascript" src="/tp50/public/static/ueditor/ueditor.parse.js"></script>
    <script type="text/javascript" src="/tp50/public/static/ueditor/ueditor.config.js"></script>
    <script type="text/javascript" src="/tp50/public/static/ueditor/ueditor.all.min.js"></script>
    <script type="text/javascript" src="/tp50/public/static/ueditor/lang/zh-cn/zh-cn.js"></script>
    <style>
        body {
            min-width: 1080px;
            max-width: 1366px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
    <div class="header">
        <div id="banner" style="width:100%;height:350px;">
            <div id="banner_bg">
            </div>
            <!--标题背景-->
            <div id="banner_info" style="display:none">
            </div>
            <!--标题-->
            <ul style="display:none">
                <li class="on">
                    1
                </li>
                <li>
                    2
                </li>
                <li>
                    3
                </li>
                <li>
                    4
                </li>
            </ul>
            <div id="banner_list">
                <a href="#" target="_blank">
                    <img id="img1" src="" title="banner图1" alt="banner图1">
                </a>
                <a href="#" target="_blank">
                    <img id="img2" src="" title="banner图2" alt="banner图2">
                </a>
                <a href="#" target="_blank">
                    <img id="img3" src="" title="banner图3" alt="banner图3">
                </a>
                <a href="#" target="_blank">
                    <img id="img4" src="" title="banner图4" alt="banner图4">
                </a>
            </div>

        </div>
        <div class="bg">

            <div class="nav">
                <ul>
                    <li class="nav_item">
                        <a href="/tp50/public/blog/index/review?viewname=index/index" class="home">HOME</a>
                    </li>
                    <!-- 
                    <li class="nav_item">
                        <a href="#">最近专题</a>
                    </li> -->
                    <!-- <li class="nav_item"><a href="#">留下足迹</a></li> -->
                    <li class="nav_item">
                        <a href="/tp50/public/blog/index/review?viewname=index/aboutme">关于我</a>
                    </li>

                    <div class="clear"></div>
                </ul>
            </div>
            <div class="mood" id="sign">

            </div>
            <div class="clear"></div>
        </div>
    </div>
    <div class="middle-body">
        <script>
            $username = "JLoongKing"
                //获取原签名信息
                //post 请求
            $.post("/tp50/public/blog/index/select", {
                "tablename": "t_blogger", //表名
                "sql": '{"userName":"=,' + $username + '"}'
            }, function(result) {
                //显示信息
                $("#sign").html(result[0].sign)

            });
            getdata();
            //获取数据
            function getdata() {
                //post 请求
                $.post("/tp50/public/blog/index/select", {
                    "tablename": "t_banner", //表名
                    "sql": '', //查询的条件
                    "limit": "0,4" //分页
                }, function(result) {
                    //回掉函数处理，输出结果
                    //如果没有获取错误码
                    if (result.code != 401) {

                        $i = 1;
                        //遍历结果处理数据进行输出
                        result.forEach(function(item) {
                            $("#img" + $i).attr("src", item.imgurl);
                            $i++;
                        });

                    } else {
                        alert(result.info);
                    }
                });
            }
        </script>
<div class="left">

    <div id="blogtitle" style="width:100%;margin:10px auto; text-align:center;font-size:20px"></div>

    <!--note-->
    <div class="note" id="bloginner">
    </div>
</div>
<!--left结束-->
<script>
    $blogid = "JLoongKing";
    //获取本篇博文信息
    //post 请求
    $.post("/tp50/public/blog/index/select", {
        "tablename": "t_blogger", //表名
        "sql": '{"username":"=,' + $blogid + '"}'
    }, function(result) {
        //显示博文原信息
        $("#blogtitle").html("关于我");
        $("#bloginner").html(result[0].profile);
        uParse('#bloginner', {
            rootPath: '/tp50/public/static/ueditor/'
        })

    });
</script>
<div class="right"><!--右侧布局-->
    <div class="date">
        <div id="lastMon"><</div>
<div id="dTitle"></div>
        <div id="nextMon">></div>
        <div id="dataIn">
            <div id="tr" class="tr">

            </div>

        </div>



    </div>

    <!--data结束-->
<div class="new">
    <p>最新<a id="gren">文章</a></p>
    <ol id="newlist">
    <li class=""><a id="newbloglist1" style=" color: orangered ;" href="#">1sadsafsad</a></li>
    <li class=""><a id="newbloglist2" href="#">2asdsadasfas</a></li>
    <li class=""><a id="newbloglist3" href="#" >3asdfasfadgsd</a></li>
    <li class=""><a id="newbloglist4" href="#">4asfdsgfdh</a></li>
    </ol>
</div><!--new 结束-->
   <div class="hot"> <!--hot开始-->
  <p>热度排行</p>
       <ul id="hotlist">
           <li type="square" class=""><a id="hotbloglist1" style=" color: orangered ;" href="#">1sadsafsad</a></li>
           <li type="square" class=""><a id="hotbloglist2" href="#">2asdsadasfas</a></li>
           <li type="square" class=""><a id="hotbloglist3" href="#" >3asdfasfadgsd</a></li>
           <li type="square"  class=""><a id="hotbloglist4" href="#">4asfdsgfdh</a></li>
       </ul>
  </div> <!--hot结束-->
</div><!--右侧结束-->
<div class="clear"></div>
</div>
<!-- <p id="frist-words">喜欢吗？</p>
<p id="second-words">喜欢就选我吧！</p>
<p id="third-words">与你携手共进！</p> -->
</body>
<script>
      getdata1("id desc","#newbloglist");
      getdata1("clickHit desc","#hotbloglist");
    //获取数据
    function getdata1($order,$itemname) {
        //post 请求
        $.post("/tp50/public/blog/index/selectorder", {
            "tablename": "t_blog", //表名
            "sql": '', //查询的条件
            "order": $order, //排序规则
            "limit": "0,4" //分页
        }, function (result) {
            //回掉函数处理，输出结果
            //如果没有获取错误码
            if (result.code != 401) {
                $i = 1;
                //遍历结果处理数据进行输出
                result.forEach(function (item) {
                    $($itemname+$i).html(item.title);
                    $($itemname+$i).attr("href","/tp50/public/blog/index/review?viewname=index/blog&blogid="+item.id);
                    $i++;
                });
              
            } else {
                alert(result.info);
            }
        });
    }
</script>
<script src="/tp50/public/static/js/main.js"></script>
</html> <div style="clear:both" />
<!--采用container-fluid，使得整个页尾的宽度为100%，并设置它的背景色-->
<footer class="container-fluid foot-wrap">
    <!--采用container，使得页尾内容居中 -->
    <div class="container">
        <div class="row">
            <div class="row-content col-lg-4 col-sm-4 col-xs-6">
                <h3>分享到</h3>
                <ul>
                    <div class="bdsharebuttonbox">
                        <a href="#" class="bds_more" data-cmd="more"></a>
                        <a href="#" class="bds_qzone" data-cmd="qzone"></a>
                        <a href="#" class="bds_tsina" data-cmd="tsina"></a>
                        <a href="#" class="bds_tqq" data-cmd="tqq"></a>
                        <a href="#" class="bds_renren" data-cmd="renren"></a>
                        <a href="#" class="bds_weixin" data-cmd="weixin"></a>
                    </div>
                    <script>
                        window._bd_share_config = {
                            "common": {
                                "bdSnsKey": {},
                                "bdText": "",
                                "bdMini": "2",
                                "bdPic": "",
                                "bdStyle": "0",
                                "bdSize": "16"
                            },
                            "share": {},
                            "image": {
                                "viewList": ["qzone", "tsina", "tqq", "renren", "weixin"],
                                "viewText": "分享到：",
                                "viewSize": "16"
                            },
                            "selectShare": {
                                "bdContainerClass": null,
                                "bdSelectMiniList": ["qzone", "tsina", "tqq", "renren", "weixin"]
                            }
                        };
                        with(document) 0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = 'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=' + ~(-new Date() / 36e5)];
                    </script>
                </ul>
            </div>
            <div class="row-content col-lg-4 col-sm-4 col-xs-6">
                <h3>设计者</h3>
                <ul>
                    <li><a href="https://www.jloongking.cn">JLoongKing</a></li>
                </ul>
            </div>
            <div class="row-content col-lg-4 col-sm-4 col-xs-6">
                <h3>友情链接</h3>
                <ul id="linklist">
                    <li><a href="https://www.jloongking.cn">JLoongKing</a></li>
                </ul>
            </div>


        </div>
        <!--/.row -->
    </div>
    <!--/.container-->
    <p align="center" style="margin-top: 20px; font-size:10px;color: #878B91;">
        备案号辽ICP备16015900号
    </p>
    <p align="center" style="margin-top: 20px;color:#878B91;">
        Copyright &copy;2018 JLoongKing
    </p>


</footer>
<script>
    //post 请求
    $.post("/tp50/public/blog/index/select", {
        "tablename": "t_link", //表名
        "sql": '', //查询的条件
        "limit": '0,10' //分页
    }, function(result) {
        $html = "";
        //将每一项数据进行遍历，生成html代码
        //回掉函数处理，输出结果
        //如果没有获取错误码
        if (result.code != 401) {
            //遍历结果处理数据进行输出
            result.forEach(function(item) {
                $html += " <li><a href='" + item.linkUrl + "'>" + item.linkName + "</a></li>"
            });

        } else {
            alert(result.info);
        }
        $("#linklist").html($html);

    });
</script>