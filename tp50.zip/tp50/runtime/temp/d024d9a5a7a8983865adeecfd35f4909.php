<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:72:"/opt/lampp/htdocs/tp50/public/../application/blog/view/admin/banner.html";i:1526297274;s:80:"/opt/lampp/htdocs/tp50/public/../application/blog/view/admin/include/header.html";i:1527558438;}*/ ?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html lang="en" class="ie6 ielt7 ielt8 ielt9"><![endif]-->
<!--[if IE 7 ]><html lang="en" class="ie7 ielt8 ielt9"><![endif]-->
<!--[if IE 8 ]><html lang="en" class="ie8 ielt9"><![endif]-->
<!--[if IE 9 ]><html lang="en" class="ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <title>JLoongKing后台管理界面</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/tp50/public/static/css/bootstrap.min.css" rel="stylesheet">
    <link href="/tp50/public/static/css/bootstrap-responsive.min.css" rel="stylesheet">
    <link href="/tp50/public/static/css/site.css" rel="stylesheet">
    <link href="/tp50/public/static/css/banner.css" rel="stylesheet">
    <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
    <script src="https://cdn.bootcss.com/jquery-cookie/1.4.1/jquery.cookie.js"></script>
    <script src="http://cdn.static.runoob.com/libs/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link type="text/css" rel="stylesheet" href="/tp50/public/static/fileinput/css/fileinput.css" />
    <script type="text/javascript" src="/tp50/public/static/fileinput/js/fileinput.js"></script>
    <script type="text/javascript" src="/tp50/public/static/fileinput/js/locales/zh.js"></script>
    <script type="text/javascript" src="/tp50/public/static/ueditor/ueditor.config.js"></script>
    <script type="text/javascript" src="/tp50/public/static/ueditor/ueditor.all.min.js"></script>
    <script type="text/javascript" src="/tp50/public/static/ueditor/lang/zh-cn/zh-cn.js"></script>
    <script type="text/javascript" src="/tp50/public/static/js/md5.js"></script>
    <script type="text/javascript" src="/tp50/public/static/js/banner.js"></script>
</head>

<body>
    <!-- 按钮触发模态框  -->
    <button id="alert" style="display:none;" class="btn btn-primary btn-lg" type="hidden" data-toggle="modal" data-target="#myModal"> 开始演示模态框
    </button>
    <!-- 模态框（Modal） -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                        &times;
                    </button>
                    <h4 class="modal-title" id="myModalLabel">
                        网站提示：
                    </h4>
                </div>
                <div class="modal-body">
                    登陆已失效！请重新登陆
                </div>
                <div class="modal-footer">
                    <!-- <button type="button" class="btn btn-default" data-dismiss="modal">quesi
                    </button> -->
                    <button type="button" id="alertok" class="btn btn-primary">
                        确定
                    </button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal -->
    </div>

    <div class="container">
        <div class="navbar">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </a> <a class="brand" href="#">JLoongKing</a>
                    <div class="nav-collapse">
                        <ul id="nav1" class="nav">
                            <li class="main" class="active">
                                <a href="/tp50/public/blog/admin/review?viewname=index">
                                总览
                            </a>
                            </li>
                            <li class="setting">
                                <a href="/tp50/public/blog/admin/review?viewname=setting">常规设置</a>
                            </li>
                            <li class="help">
                                <a href="/tp50/public/blog/admin/review?viewname=help">帮助</a>
                            </li>
                            <li id="email" class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown">email <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="#">Introduction Tour</a>
                                    </li>
                                    <li>
                                        <a href="#">Project Organisation</a>
                                    </li>
                                    <li>
                                        <a href="#">Task Assignment</a>
                                    </li>
                                    <li>
                                        <a href="#">Access Permissions</a>
                                    </li>
                                    <li class="divider">
                                    </li>
                                    <li class="nav-header">
                                        Files
                                    </li>
                                    <li>
                                        <a href="#">How to upload multiple files</a>
                                    </li>
                                    <li>
                                        <a href="#">Using file version</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul class="nav pull-right">
                            <li>
                                <a href="/tp50/public/blog/admin/review?viewname=index" id="username">@</a>
                            </li>
                            <li>
                                <a href="/tp50/public/blog/admin/review?viewname=login">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="span3">
                <div class="well" style="padding: 8px 0;">
                    <ul id="nav2" class="nav nav-list">
                        <li class="divider">
                            <li class="nav-header">
                                JLoongKing
                            </li>
                            <li class="divider">
                                <li id="bannersetting">
                                    <a href="/tp50/public/blog/admin/review?viewname=banner"><i class="icon-folder-open"></i> banner图设置</a>
                                </li>
                                <li id="color">
                                    <a href="/tp50/public/blog/admin/review?viewname=color"><i class="icon-folder-open"></i> 主题设置</a>
                                </li>
                                <li class="divider"></li>
                                <li class="nav-header">
                                    Blog
                                </li>
                                <li class="divider">
                                </li>
                                <li id="bloglist">
                                    <a class="bloglist" href="/tp50/public/blog/admin/review?viewname=admin/blog/bloglist"><i class="icon-file"></i>博文列表</a>
                                </li>
                                <li id="createnewblog">
                                    <a href="/tp50/public/blog/admin/review?viewname=admin/blog/new"><i class="icon-list-alt"></i> 上传文章</a>
                                </li>

                                <li class="divider"></li>
                                <li class="nav-header">
                                    Blogger
                                </li>
                                <li class="divider">
                                </li>
                                <li id="sign">
                                    <a href="/tp50/public/blog/admin/review?viewname=admin/admininfo/modifysign"><i class="icon-check"></i> 修改签名</a>
                                </li>
                                <li id="password">
                                    <a href="/tp50/public/blog/admin/review?viewname=admin/admininfo/modifypassword"><i class="icon-envelope"></i> 修改密码</a>
                                </li>
                                <li id="icon">
                                    <a href="/tp50/public/blog/admin/review?viewname=admin/admininfo/modifyicon"><i class="icon-envelope"></i> 修改头像</a>
                                </li>
                                <li id="info">
                                    <a href="/tp50/public/blog/admin/review?viewname=admin/admininfo/modifyinfo"><i class="icon-envelope"></i> 修改详细信息</a>
                                </li>
                                <li class="divider">
                                    <li class="nav-header">
                                        BlogType
                                    </li>
                                    <li class="divider">
                                    </li>
                                    <li id="type">
                                        <a href="/tp50/public/blog/admin/review?viewname=admin/blogtype/blogtypelist"><i class="icon-check"></i> 所有标签</a>
                                    </li>
                                    <li id="addtype">
                                        <a href="/tp50/public/blog/admin/review?viewname=admin/blogtype/blogtypeadd"><i class="icon-envelope"></i> 标签增加</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li class="nav-header">
                                        Link
                                    </li>
                                    <li class="divider">
                                    </li>
                                    <li id="link">
                                        <a href="/tp50/public/blog/admin/review?viewname=admin/link/linklist"><i class="icon-check"></i> 友情链接列表</a>
                                    </li>
                                    <li id="newlink">
                                        <a href="/tp50/public/blog/admin/review?viewname=admin/link/addlink"><i class="icon-envelope"></i> 友情链接增加</a>
                                    </li>
                                    <li class="nav-header">
                                        Comment
                                    </li>
                                    <li class="divider">
                                    </li>
                                    <li id="Comment">
                                        <a href="/tp50/public/blog/admin/review?viewname=admin/comment/commentlist"><i class="icon-check"></i> 评论列表</a>
                                    </li>
                                   
                    </ul>
                </div>
            </div>
            <script>
                if ($.cookie('username') == undefined) {
                    $("#alert").click();
                    $("#alertok").click(function() {
                        window.location.href = "/tp50/public/blog/admin/review?viewname=login";
                    });
                } else {
                    $("#username").text("@" + $.cookie('username'));
                }
                //更换活动标签（active）

                $(".active").removeClass("active");

                $("#createnewblog").addClass("active");
            </script>
<div class="span9">
    <h1>
        Banner&nbsp;&nbsp;&nbsp;&nbsp;
        <strong>
            <small style="text-decoration:blink;font-size:small;color:teal;">设置banner图</small>
        </strong>
    </h1>
    <div id="banner">
        <div id="banner_bg">
        </div>
        <!--标题背景-->
        <div id="banner_info">
        </div>
        <!--标题-->
        <ul>
            <li class="on">
                1
            </li>
            <li>
                2
            </li>
            <li>
                3
            </li>
            <li>
                4
            </li>
        </ul>
        <div id="banner_list">
            <a href="#" target="_blank">
                <img id="img1" src="imgs/p1.jpg" title="banner图1" alt="banner图1">
            </a>
            <a href="#" target="_blank">
                <img id="img2" src="imgs/p2.jpg" title="banner图2" alt="banner图2">
            </a>
            <a href="#" target="_blank">
                <img id="img3" src="imgs/p3.jpg" title="banner图3" alt="banner图3">
            </a>
            <a href="#" target="_blank">
                <img id="img4" src="imgs/p1.jpg" title="banner图4" alt="banner图4">
            </a>
        </div>

    </div>
    <div style="width:80%;margin:auto">
        <div class="row-fluid" style="margin:0px;padding:0px;">
            <div class="span6" style="margin:25px 0 0 0;">
                <div class="file-container" style="display:inline-block;position:relative;overflow: hidden;vertical-align:middle">
                    <button class="btn btn-success fileinput-button" type="button">修改图片1</button>
                    <input type="file" class="file_img" onchange="loadFile(this.files[0],1)" style="position:absolute;top:0;left:0;font-size:34px; opacity:0">
                    <span id="filename1" style="vertical-align: middle">未上传文件</span>
                </div>
            </div>
            <div class="span6" style="margin:25px 0 0 0;">
                <div class="file-container" style="display:inline-block;position:relative;overflow: hidden;vertical-align:middle">
                    <button class="btn btn-success fileinput-button" type="button">修改图片2</button>
                    <input type="file" class="file_img" onchange="loadFile(this.files[0],2)" style="position:absolute;top:0;left:0;font-size:34px; opacity:0">
                    <span id="filename2" style="vertical-align: middle">未上传文件</span>
                </div>
            </div>
            <div class="span6" style="margin:25px 0 0 0;">
                <div class="file-container" style="display:inline-block;position:relative;overflow: hidden;vertical-align:middle">
                    <button class="btn btn-success fileinput-button" type="button">修改图片3</button>
                    <input type="file" class="file_img" onchange="loadFile(this.files[0],3)" style="position:absolute;top:0;left:0;font-size:34px; opacity:0">
                    <span id="filename3" style="vertical-align: middle">未上传文件</span>
                </div>
            </div>
            <div class="span6" style="margin:25px 0 0 0;">
                <div class="file-container" style="display:inline-block;position:relative;overflow: hidden;vertical-align:middle">
                    <button class="btn btn-success fileinput-button" type="button">修改图片4</button>
                    <input type="file" class="file_img" onchange="loadFile(this.files[0],4)" style="position:absolute;top:0;left:0;font-size:34px; opacity:0">
                    <span id="filename4" style="vertical-align: middle">未上传文件</span>
                </div>
            </div>
        </div>
    </div>
    <!-- <button class="btn btn-large btn-block" onclick="update()" type="button">修改</button> -->
    <div style="margin-top:20px;text-align:center;">
        <button style="width:15%" class="btn btn-primary" onclick="update()" type="button">上传</button>
    </div>
</div>

</body>


</html>
<script>
    getdata();
    //获取数据
    function getdata() {
        //post 请求
        $.post("/tp50/public/blog/admin/select", {
            "tablename": "t_banner", //表名
            "sql": '', //查询的条件
            "limit": "0,4" //分页
        }, function (result) {
            //回掉函数处理，输出结果
            //如果没有获取错误码
            if (result.code != 401) {
                $html = "";
                $i = 1;
                //遍历结果处理数据进行输出
                result.forEach(function (item) {
                    $("#img" + $i).attr("src", item.imgurl);
                    $i++;
                });
                $("#tbody").html($html);
            } else {
                alert(result.info);
            }
        });
    }
    function loadFile(file, order) {
        console.log(order);
        $("#filename" + order).html(file.name);
        $("#img" + order).attr("src", "/tp50/public/static/img/load.gif");
        var fd = new FormData();
        fd.append("upfile", file);
        $.ajax({
            url: '/tp50/public/blog/fileuploader/up',
            type: "post",
            processData: false,
            contentType: false,
            data: fd,
            success: function (result) {
                if (result.code != 400) {
                    alert("上传失败！");
                    $("#img" + order).attr("src", "/tp50/public/static/img/imgfailed.jpg");
                } else {
                    $("#img" + order).attr("src", result.url);
                }
            },
            error: function (result) {

                alert("上传失败！");
                $("#img" + order).attr("src", "/tp50/public/static/img/imgfailed.jpg");

            },
        });

    }
    //更换活动标签（active）

    $(".active").removeClass("active");

    $("#bannersetting").addClass("active");

    function update() {
        $imgurl = new Array()
        $imgurl[0] = $("#img1").attr("src");
        $imgurl[1] = $("#img2").attr("src");
        $imgurl[2] = $("#img3").attr("src");
        $imgurl[3] = $("#img4").attr("src");
        postimg(1, $imgurl[0]);


    }
    function postimg(id, imgurl) {
        //post 请求
        //上传banner
        $.post("/tp50/public/blog/admin/update", {
            "tablename": "t_banner", //表名
            "fieldname": "id",
            "fieldvalue": id,
            "data": {
                "imgurl": imgurl,
            }, //上传数据
        }, function (result) {
            //回掉函数处理，输出结果
            //如果没有获取错误码
            if (result.code != 401) {
                id++;
                if (id == 5) {
                    alert(result.info);
                    window.location.href = "/tp50/public/blog/admin/review?viewname=banner";
                }
                if (id <= 4) {
                    postimg(id, $imgurl[id - 1]);
                }



            } else {
                alert(result.info);
            }
        });
    }
</script>